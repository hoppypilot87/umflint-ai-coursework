# CIFAR-10 Image Classification – Phase One

This folder contains two notebooks that build and evaluate models to classify images using the CIFAR-10 dataset.

- `cifar10-original-haapala.ipynb` – original, unmodified version
- `cifar10-overlapleak-haapala.ipynb` – modified version

Both notebooks are intended to be run in **Google Colab** and require no additional setup.  
Simply open each notebook and click **Run All** to execute.

Model performance (Accuracy) is displayed at the end of each notebook.
