# Fashion MNIST Classification – Phase One

This folder contains two notebooks that build and evaluate models to classify clothing images using the Fashion MNIST dataset.

- `mnist-original-haapala.ipynb` – original, unmodified version
- `mnist-leaky-preprocessing-haapala.ipynb` – modified version

Both notebooks are intended to be run in **Google Colab** and require no additional setup.  
Simply open each notebook and click **Run All** to execute.

Model performance (Accuracy) is displayed at the end of each notebook.
