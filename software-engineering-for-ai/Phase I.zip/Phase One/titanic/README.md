# Titanic Project – Phase One

This folder consists of two notebooks related to Titanic survival prediction:

- `titanic-original-haapala.ipynb` – original version
- `titanic-overlapleak-haapala.ipynb` – modified version

These notebooks are intended to be run on **Kaggle.com**, which provides built-in access to the Titanic dataset. 
No setup or external data is required - simply upload the notebooks to a Kaggle Notebook environment and click **"Run All"**.

Model performance results are printed at the end of each notebook. 
