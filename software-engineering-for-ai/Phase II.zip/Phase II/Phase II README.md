Phase II – Submission Contents

This folder contains two corrected notebooks and documentation:

1. `credit card fraud detection predictive models leakage_fixed.ipynb`
- Leak type: Preprocessing
- ROC AUC before: 0.963026
- ROC AUC after: 0.963027
- Leakage report inside notebook (top)

2. `house price prediction - leak_fixed.ipynb`
- Leak type: Overlap
- RMSE before: 0.12144
- RMSE after: 0.12756
- Leakage report inside notebook (top)

Each file includes comments where the leak was fixed.
